# ==============================================================================
# KO_Test: Kernel-Orthogonality Test for Factor Risk Premia Identification
# ==============================================================================
#
# Implements the KO test of Hansen and Kazemi (2025) to determine whether
# individual factor risk premia are identified in linear factor models.
#
# INPUTS:
#   Y      - T x N matrix of asset excess returns (no NAs allowed)
#   X      - T x K matrix of factor realizations, no constant (no NAs allowed)
#   alpha  - Significance level for tests (default = 0.05)
#
# OUTPUTS (named list):
#   rank       - Estimated rank of beta matrix (integer 0 to K)
#   rank_pvals - (K+1) x 1 p-values from sequential rank test
#   KO         - K x 1 character vector: "ID" or "NoID" for each factor
#   KO_pvals   - K x 1 numeric p-values for KO test
#
# METHOD:
#   Stage 1: Estimate rank of B using Cragg and Donald (1997) sequential test
#   Stage 2: For each factor, test kernel-orthogonality condition
#
# DEGREES OF FREEDOM:
#   d = 1: chi-square with (N - K + 2) df (exact, Proposition 4.1)
#   d > 1: chi-square with (N * d) df (conservative, Proposition 4.2)
#
# SPECIAL CASES:
#   rank = K: All factors identified (no test needed)
#   rank = 0: No factors identified
#
# ASSUMPTIONS:
#   - iid returns (HAC extension straightforward but not implemented)
#   - Warns if covariance matrix is ill-conditioned (kappa > 1e10)
#
# REQUIRED PACKAGES: matrixcalc, MASS, Rsolnp
#
# ==============================================================================
KO_Test <- function(Y, X, alpha = 0.05) {
  
  
  # ============================================================================
  # INPUT VALIDATION
  
  # ============================================================================
  
  # Check for required packages
  
  required_pkgs <- c("matrixcalc", "Rsolnp", "MASS")
  missing_pkgs <- required_pkgs[!sapply(required_pkgs, requireNamespace, quietly = TRUE)]
  if (length(missing_pkgs) > 0) {
    stop(paste("Missing required packages:", paste(missing_pkgs, collapse = ", "),
               "\nInstall with: install.packages(c('",
               paste(missing_pkgs, collapse = "', '"), "'))", sep = ""))
  }
  
  # Coerce to matrix if necessary
  if (!is.matrix(Y)) Y <- as.matrix(Y)
  if (!is.matrix(X)) X <- as.matrix(X)
  
  # Extract dimensions
  T_Y <- nrow(Y)
  T_X <- nrow(X)
  N   <- ncol(Y)  # Number of test assets
  K   <- ncol(X)  # Number of factors
  
  # Validate dimensions
  if (T_Y != T_X) {
    stop("Y and X must have the same number of rows (time periods)")
  }
  Time <- T_Y
  
  # Check for missing values
  if (any(is.na(Y)) || any(is.na(X))) {
    stop("Missing values detected. Y and X must have no NAs.")
  }
  
  # Check sufficient observations
  if (Time <= K) {
    stop("Need more time periods (T) than factors (K)")
  }
  
  # Check sufficient assets
  if (N <= K) {
    stop("Need more assets (N) than factors (K)")
  }
  
  
  # ============================================================================
  # ESTIMATE BETAS
  # ============================================================================
  
  # De-mean returns and factors
  Y <- Y - matrix(colMeans(Y), nrow = Time, ncol = N, byrow = TRUE)
  X <- X - matrix(colMeans(X), nrow = Time, ncol = K, byrow = TRUE)
  
  # OLS betas: B = (X'X)^{-1} X'Y, stored as N x K
  Betas <- t(solve(t(X) %*% X) %*% t(X) %*% Y)
  
  
  # ============================================================================
  # STAGE 1: RANK ESTIMATION (Cragg and Donald, 1997)
  # ============================================================================
  
  # Factor covariance matrix
  CovF <- cov(X)
  
  # Regression residuals
  Eps <- Y - X %*% t(Betas)
  
  # Residual covariance matrix (df-adjusted)
  CovMatE <- (1 / (Time - K)) * t(Eps) %*% Eps
  
  # Covariance matrix of vec(Beta) under iid assumption
  # Omega_B = Sigma_eps \otimes Sigma_f^{-1}
  Omega_R <- CovMatE %x% solve(CovF)
  
  # Matrix for eigenvalue decomposition: Sigma_f * B' * Sigma_eps^{-1} * B
  PsiMat <- CovF %*% t(Betas) %*% solve(CovMatE) %*% Betas
  
  # Eigenvalues in ascending order
  Ei <- sort(eigen(PsiMat)$values)
  
  # Sequential rank test
  # H0: rank(B) = p, for p = 0, 1, ..., K
  pvalR <- matrix(NA, nrow = K + 1)
  
  for (p in 0:K) {
    
    # Test statistic: T * sum of smallest (K-p) eigenvalues
    if (p < K) {
      Obj <- Time * sum(Ei[1:(K - p)])
    } else {
      Obj <- 0
    }
    
    # Degrees of freedom: (N-p)(K-p)
    df_rank <- (N - p) * (K - p)
    pvalR[p + 1] <- pchisq(Obj, df_rank, lower.tail = FALSE)
    
    # Stop at first p where we fail to reject
    if (pvalR[p + 1] > alpha) {
      break
    }
  }
  
  # Estimated rank
  r <- p
  
  
  # ============================================================================
  # STAGE 2: KERNEL-ORTHOGONALITY TEST
  # ============================================================================
  
  # Handle special cases first
  if (r == 0) {
    # Rank zero: no factors identified
    KO   <- rep("NoID", K)
    pval <- rep(0, K)
    
    return(list(
      rank       = r,
      rank_pvals = pvalR,
      KO         = KO,
      KO_pvals   = pval
    ))
  }
  
  if (r == K) {
    # Full rank: all factors identified by construction
    KO   <- rep("ID", K)
    pval <- rep(NA, K)
    
    return(list(
      rank       = r,
      rank_pvals = pvalR,
      KO         = KO,
      KO_pvals   = pval
    ))
  }
  
  # ----------------------------------------------------------------------------
  # General case: 0 < r < K (rank deficiency exists)
  # ----------------------------------------------------------------------------
  
  # Dimension of rank deficiency
  d <- K - r
  
  # Degrees of freedom for KO test
  # d = 1: exact test with df = N - K + 2 (Proposition 4.1)
  # d > 1: conservative test with df = N * d (Proposition 4.2)
  if (d == 1) {
    df_KO <- N - K + 2
  } else {
    df_KO <- N * d
  }
  
  # Initialize output vectors
  KO   <- character(K)
  pval <- numeric(K)
  
  # --------------------------------------------------------------------------
  # Special case: K = 2 and d = 1
  # No optimization needed; test U = [1,0]' and U = [0,1]' directly
  # --------------------------------------------------------------------------
  
  if (d == 1 && K == 2) {
    
    IN <- diag(N)
    
    for (pos in 1:K) {
      
      # Construct U: unit vector with zero in position 'pos'
      U <- matrix(1, K, d)
      U[pos] <- 0
      
      # Covariance matrix of vec(B * U)
      OmegaU <- (IN %x% t(U)) %*% Omega_R %*% (IN %x% U)
      
      # Check conditioning
      cond_num <- kappa(OmegaU)
      if (cond_num > 1e10) {
        warning(paste("Factor", pos, ": OmegaU ill-conditioned (kappa =",
                      format(cond_num, scientific = TRUE), ")"))
      }
      
      # Test statistic: T * (B*U)' * Omega^{-1} * (B*U)
      BU <- matrixcalc::vec(t(Betas %*% U))
      test_stat <- as.numeric(Time * t(BU) %*% MASS::ginv(OmegaU) %*% BU)
      
      # P-value and decision
      pval[pos] <- pchisq(test_stat, df_KO, lower.tail = FALSE)
      KO[pos]   <- ifelse(pval[pos] > alpha, "ID", "NoID")
    }
    
  } else {
    
    # --------------------------------------------------------------------------
    # General case: K > 2 or d > 1
    # Requires constrained optimization over the Stiefel manifold
    # --------------------------------------------------------------------------
    
    IN <- diag(N)
    
    for (pos in 1:K) {
      
      # --------------------------------------------------------------------
      # Define equality constraint function
      # Constraints: U'U = I_d (orthonormality) with U[pos,] = 0
      # --------------------------------------------------------------------
      
      eqcon_fun <- function(u) {
        
        # Reshape vector to (K-1) x d matrix, then embed in K x d
        U <- matrix(u, nrow = K - 1, ncol = d)
        U_full <- matrix(0, K, d)
        U_full[-pos, ] <- U
        
        # Orthonormality: U'U = I_d
        # Return lower triangular elements (including diagonal)
        UpU <- t(U_full) %*% U_full
        constraint <- UpU[lower.tri(UpU, diag = TRUE)]
        
        return(constraint)
      }
      
      # --------------------------------------------------------------------
      # Define objective function (test statistic to minimize)
      # --------------------------------------------------------------------
      
      optfun <- function(u) {
        
        # Reshape vector to (K-1) x d matrix, then embed in K x d
        U <- matrix(u, nrow = K - 1, ncol = d)
        U_full <- matrix(0, K, d)
        U_full[-pos, ] <- U
        
        # Covariance matrix of vec(B * U)
        OmegaU <- (IN %x% t(U_full)) %*% Omega_R %*% (IN %x% U_full)
        
        # Test statistic
        BU <- matrixcalc::vec(t(Betas %*% U_full))
        test_stat <- Time * t(BU) %*% MASS::ginv(OmegaU) %*% BU
        
        return(as.numeric(test_stat))
      }
      
      # --------------------------------------------------------------------
      # Set up constraint target (I_d in lower triangular form)
      # --------------------------------------------------------------------
      
      Z <- matrix(0, K - 1, d)
      diag(Z) <- 1
      Z_full <- matrix(0, K, d)
      Z_full[-pos, ] <- Z
      
      ZZ <- t(Z_full) %*% Z_full
      target <- ZZ[lower.tri(ZZ, diag = TRUE)]
      
      # --------------------------------------------------------------------
      # Solve constrained optimization
      # --------------------------------------------------------------------
      
      start <- rnorm((K - 1) * d)
      
      Sol <- Rsolnp::solnp(
        pars    = start,
        fun     = optfun,
        eqfun   = eqcon_fun,
        eqB     = target,
        control = list(trace = 0)
      )
      
      # --------------------------------------------------------------------
      # Check conditioning at solution
      # --------------------------------------------------------------------
      
      u_final <- Sol$pars
      U_final <- matrix(u_final, nrow = K - 1, ncol = d)
      U0_final <- matrix(0, K, d)
      U0_final[-pos, ] <- U_final
      
      OmegaU_final <- (IN %x% t(U0_final)) %*% Omega_R %*% (IN %x% U0_final)
      cond_num <- kappa(OmegaU_final)
      
      if (cond_num > 1e10) {
        warning(paste("Factor", pos,
                      ": OmegaU ill-conditioned at solution (kappa =",
                      format(cond_num, scientific = TRUE), ")"))
      }
      
      # --------------------------------------------------------------------
      # Extract test statistic, compute p-value and decision
      # --------------------------------------------------------------------
      
      test_stat <- Sol$values[length(Sol$values)]
      pval[pos] <- pchisq(test_stat, df_KO, lower.tail = FALSE)
      KO[pos]   <- ifelse(pval[pos] > alpha, "ID", "NoID")
      
    }  # end loop over factors
    
  }  # end if K=2/d=1 vs general case
  
  
  # ============================================================================
  # RETURN RESULTS
  # ============================================================================
  
  return(list(
    rank       = r,
    rank_pvals = pvalR,
    KO         = KO,
    KO_pvals   = pval
  ))
  
}