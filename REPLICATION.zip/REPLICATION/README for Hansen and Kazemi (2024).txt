================================================================================
README for Hansen and Kazemi (2024)
"Identification of Factor Risk Premia"
================================================================================


OVERVIEW
--------------------------------------------------------------------------------
This replication package contains code to reproduce the empirical results in
Hansen and Kazemi (2024). The package includes:

  1. The KO test function for testing identification of factor risk premia
  2. Data construction scripts for each empirical application
  3. Replication scripts that reproduce the paper's tables


FOLDER STRUCTURE
--------------------------------------------------------------------------------
/Replication/
├── README.txt              This file
├── setup_paths.R           Path configuration (edit if needed)
├── KO_Test.R               Main KO test function
├── Make_AEM_Data.R         Data construction for Adrian et al. (2014)
├── Make_Yogo_Data.R        Data construction for Yogo (2006)
├── Replicate_AEM.R         Replicates Tables 1-4
├── Replicate_Yogo.R        Replicates Tables 5-8
└── Data/
    ├── F-F_Research_Data_Factors.csv
    ├── AEM_LevFactor.csv
    ├── 25_Portfolios_5x5.csv
    ├── CBased_Data.xls
    └── (generated .rds files)


INSTRUCTIONS
--------------------------------------------------------------------------------
1. Place all .R files in a single folder (e.g., "Replication/")

2. Create a "Data" subfolder containing the required raw data files

3. Open any script in RStudio and run it. The scripts automatically:
   - Set the working directory to the script location
   - Source setup_paths.R for consistent path configuration
   - Create an "Output" folder if needed

4. Run the data construction scripts first:
   - Make_AEM_Data.R  -->  creates Adrian_Etula_Muir_Data.rds
   - Make_Yogo_Data.R -->  creates Yogo_Data.rds

5. Then run the replication scripts:
   - Replicate_AEM.R  -->  Tables 1-4 (Adrian et al. application)
   - Replicate_Yogo.R -->  Tables 5-8 (Yogo application)


DATA SOURCES
--------------------------------------------------------------------------------
Test Assets and Market Return:
  - 25 Fama-French portfolios sorted on size and book-to-market
  - Downloaded from Ken French's website:
    https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html

Adrian, Etula, and Muir (2014):
  - Intermediary leverage factor from Tyler Muir's website:
    https://tylermuir.com/data

Yogo (2006):
  - Consumption growth data from Motohiro Yogo's website
  - File: CBased_Data.xls (Sheet 2)


DATA TRANSFORMATIONS
--------------------------------------------------------------------------------
For both applications, the following transformations are applied:

  1. Monthly returns are compounded to quarterly frequency
  2. Factors are merged with the market excess return
  3. Excess returns are computed by subtracting the risk-free rate


KO TEST FUNCTION
--------------------------------------------------------------------------------
The KO_Test.R file implements the kernel-orthogonality test described in the
paper. 

Usage:
  result <- KO_Test(Y, X, alpha = 0.05)

Inputs:
  Y      - T x N matrix of test asset excess returns (no missing values)
  X      - T x K matrix of factor realizations, no constant (no missing values)
  alpha  - Significance level for tests (default = 0.05)

Outputs (named list):
  rank       - Estimated rank of beta matrix (integer 0 to K)
  rank_pvals - P-values from sequential rank test (Cragg and Donald, 1997)
  KO         - Character vector: "ID" or "NoID" for each factor
  KO_pvals   - P-values for the KO test for each factor

Required packages: matrixcalc, MASS, Rsolnp


REPLICATION OUTPUT
--------------------------------------------------------------------------------
Each replication script prints results to the console that correspond to the
paper's tables:

Replicate_AEM.R:
  - Table 1: Sequential rank test results
  - Table 2: KO test results for Market and Intermediary Leverage
  - Table 3: Fama-MacBeth risk premia estimates
  - Table 4: Factor covariance matrix and condition number

Replicate_Yogo.R:
  - Table 5: Sequential rank test results
  - Table 6: KO test results for consumption factors and Market
  - Table 7: Fama-MacBeth risk premia estimates
  - Table 8: Factor covariance matrix and condition number


NOTES
--------------------------------------------------------------------------------
- All panels must be balanced (no missing values)

- The Fama-MacBeth standard errors in the replication files are OLS standard
  errors, not Shanken-corrected. This is noted in the output.

- The KO test uses iid asymptotics. HAC-robust inference is a straightforward
  extension but is not implemented in this version.



REQUIRED R PACKAGES
--------------------------------------------------------------------------------
  - dplyr
  - tidyr
  - readr
  - readxl
  - MASS
  - matrixcalc
  - Rsolnp

Install with:
  install.packages(c("dplyr", "tidyr", "readr", "readxl", 
                     "MASS", "matrixcalc", "Rsolnp"))


CONTACT
--------------------------------------------------------------------------------
For questions about the replication package, please contact the authors.

================================================================================