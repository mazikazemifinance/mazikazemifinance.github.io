# ==============================================================================
# Replicate_Yogo.R
# ==============================================================================
#
# Replicates the Yogo (2006) analysis from:
#   Hansen and Kazemi (2024), "Identification of Factor Risk Premia"
#
# This script:
#   1. Runs the KO identification test on the three-factor model 
#      (Nondurable consumption, Durable consumption, Market)
#   2. Tests sensitivity of results to optimization starting values
#   3. Estimates Fama-MacBeth risk premia for comparison
#   4. Reports factor covariance matrix and condition number
#
# REQUIRED FILES:
#   - KO_Test.R                (KO test function)
#   - Data/Yogo_Data.rds       (created by Make_Yogo_Data.R)
#
# REPLICATES:
#   - Table 5: Sequential rank test results
#   - Table 6: KO test results
#   - Table 7: Fama-MacBeth estimates
#   - Table 8: Factor covariance matrix
#
# ==============================================================================

rm(list = ls())

# Set working directory to script location
if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
}

# Load required packages
library(dplyr)
library(tidyr)
library(MASS)
library(matrixcalc)
library(Rsolnp)

# Source setup and helper functions
source("setup_paths.R")
paths <- setup_paths()
list2env(paths, envir = .GlobalEnv)

# Source KO test function
source("KO_Test.R")


# ==============================================================================
# PARAMETERS
# ==============================================================================

N    <- 25   # Number of test assets
K    <- 3    # Number of factors
Skip <- 2    # Columns to skip (Year, Month)


# ==============================================================================
# LOAD DATA
# ==============================================================================

Data <- readRDS(file.path(DataDir, "Yogo_Data.rds"))

# Extract test assets (Y) and factors (X)
Y <- as.matrix(Data[, (Skip + 1):(N + Skip)])
X <- as.matrix(Data[, (N + Skip + 1):(N + K + Skip)])

cat("\n")
cat("==============================================================================\n")
cat("Yogo (2006) - Three Factor Model\n")
cat("==============================================================================\n")
cat("Sample period:", min(Data$Year), "-", max(Data$Year), "\n")
cat("Observations:", nrow(Data), "\n")
cat("Test assets:", N, "\n")
cat("Factors:", paste(colnames(X), collapse = ", "), "\n")
cat("\n")




# ==============================================================================
# KO IDENTIFICATION TEST
# ==============================================================================

KO <- KO_Test(Y, X)

cat("------------------------------------------------------------------------------\n")
cat("TABLE 5: Sequential Rank Test (Cragg and Donald, 1997)\n")
cat("------------------------------------------------------------------------------\n")
cat("Estimated rank:", KO$rank, "\n\n")
cat("P-values:\n")
for (i in 0:K) {
  if (!is.na(KO$rank_pvals[i + 1])) {
    cat(sprintf("  H0: rank = %d    p-value = %.4f\n", i, KO$rank_pvals[i + 1]))
  }
}
cat("\n")

cat("------------------------------------------------------------------------------\n")
cat("TABLE 6: Kernel-Orthogonality Test Results\n")
cat("------------------------------------------------------------------------------\n")
cat(sprintf("%-30s %-10s %s\n", "Factor", "Status", "P-value"))
cat(sprintf("%-30s %-10s %s\n", "------", "------", "-------"))
for (i in 1:K) {
  pval_str <- ifelse(is.na(KO$KO_pvals[i]), "NA", 
                     ifelse(KO$KO_pvals[i] < 0.01, "< 0.01", 
                            sprintf("%.3f", KO$KO_pvals[i])))
  cat(sprintf("%-30s %-10s %s\n", colnames(X)[i], KO$KO[i], pval_str))
}
cat("\n")


# ==============================================================================
# FAMA-MACBETH ESTIMATION
# ==============================================================================

# Test asset names
Nam <- names(Data)[(Skip + 1):(N + Skip)]

# Reshape to long format
LongDat <- Data %>%
  pivot_longer(cols = all_of(Nam), names_to = "name", values_to = "value")

# First pass: Time-series regressions to estimate betas (no intercept)
Bet <- LongDat %>%
  group_by(name) %>%
  do(R = lm(value ~ 0 + GrowthNondur + GrowthDur + MKTRF, .)) %>%
  ungroup()

Bet <- Bet %>%
  group_by(name) %>%
  mutate(
    BND = R[[1]]$coefficients[1],
    BD  = R[[1]]$coefficients[2],
    BM  = R[[1]]$coefficients[3]
  ) %>%
  ungroup() %>%
  dplyr::select(-R)

# Merge betas back to data
FB <- LongDat %>%
  left_join(Bet, by = "name")

# Second pass: Cross-sectional regressions each period
FB <- FB %>%
  group_by(Year, Month) %>%
  do(R = lm(value ~ BND + BD + BM, .)) %>%
  ungroup()

# Extract risk premia estimates
FB <- FB %>%
  group_by(Year, Month) %>%
  summarize(
    LND = R[[1]]$coefficients[2],
    LD  = R[[1]]$coefficients[3],
    LM  = R[[1]]$coefficients[4],
    .groups = "drop"
  )

# Test significance (t-test on time-series mean)
R1 <- lm(LND ~ 1, FB)
R2 <- lm(LD ~ 1, FB)
R3 <- lm(LM ~ 1, FB)

cat("------------------------------------------------------------------------------\n")
cat("TABLE 7: Fama-MacBeth Risk Premia Estimates\n")
cat("------------------------------------------------------------------------------\n")
cat("Note: Standard errors are OLS (not Shanken-corrected)\n\n")
cat(sprintf("%-30s %12s %12s %12s\n", "Factor", "Risk Premium", "Std. Error", "P-value"))
cat(sprintf("%-30s %12s %12s %12s\n", "------", "------------", "----------", "-------"))

# Nondurable consumption
coef1 <- summary(R1)$coefficients
cat(sprintf("%-30s %12.4f %12.4f %12.4f\n", 
            "Nondurable Consumption", coef1[1, 1], coef1[1, 2], coef1[1, 4]))

# Durable consumption
coef2 <- summary(R2)$coefficients
cat(sprintf("%-30s %12.4f %12.4f %12.4f\n", 
            "Durable Consumption", coef2[1, 1], coef2[1, 2], coef2[1, 4]))

# Market
coef3 <- summary(R3)$coefficients
cat(sprintf("%-30s %12.4f %12.4f %12.4f\n", 
            "Market", coef3[1, 1], coef3[1, 2], coef3[1, 4]))

# Annualize
cat("\nAnnualized risk premia (x4 for quarterly data):\n")
cat(sprintf("  Nondurable Consumption: %.4f\n", 4 * coef1[1, 1]))
cat(sprintf("  Durable Consumption:    %.4f\n", 4 * coef2[1, 1]))
cat(sprintf("  Market:                 %.4f\n", 4 * coef3[1, 1]))
cat("\n")


# ==============================================================================
# FACTOR COVARIANCE MATRIX
# ==============================================================================

CovX <- cov(X)

cat("------------------------------------------------------------------------------\n")
cat("TABLE 8: Factor Covariance Matrix\n")
cat("------------------------------------------------------------------------------\n")
print(CovX, digits = 4)
cat("\nCondition number:", round(kappa(CovX), 3), "\n")
cat("\n")


# ==============================================================================
# SUMMARY
# ==============================================================================

cat("==============================================================================\n")
cat("SUMMARY\n")
cat("==============================================================================\n")
cat("The KO test indicates:\n")
for (i in 1:K) {
  status <- ifelse(KO$KO[i] == "ID", "IS identified", "is NOT identified")
  cat(sprintf("  - %s risk premium %s\n", colnames(X)[i], status))
}
cat("\n")
cat("Note: High condition number (", round(kappa(CovX), 1), 
    ") suggests factors may be\n", sep = "")
cat("near-collinear, which can contribute to identification failure.\n")
cat("\n")